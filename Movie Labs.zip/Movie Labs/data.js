let movies = [
    {
        name: "Star Wars : Anakin",
        des: "Découvrez la perfection dans la reproduction du sabre laser emblématique d'Anakin Skywalker. Notre réplique captivante, réalisée avec précision, rend hommage à l'arme légendaire du Chevalier Jedi. Obtenez cette pièce de collection exceptionnelle dès maintenant, disponible en exclusivité sur notre site.",
        image: 'images/lightsaber.jpeg'
    },
    {
        name: "Marvel's : The Shield",
        des: "Découvrez la réplique haut de gamme du bouclier emblématique de Captain America. Fabriquée avec précision et détails authentiques, notre collection offre une qualité exceptionnelle pour les passionnés. Apportez la puissance du Premier Avenger chez vous avec cette reproduction fidèle, disponible exclusivement sur notre site.",
        image: 'images/shield.jpg'
    },
    {
        name: 'Manga: Zenitsu',
        des: "Explorez l'exquise réplique du katana de Zenitsu, inspiré de Demon Slayer. Avec une attention méticuleuse aux détails, notre collection offre une fidélité exceptionnelle à l'arme du personnage. Élevez votre collection avec cette reproduction de qualité, disponible exclusivement sur notre site.",
        image: 'images/zenitsu.webp'
    },

]